//>>built
define("dijit/nls/ja/common",({buttonOk:"OK",buttonCancel:"キャンセル",buttonSave:"保存",itemClose:"閉じる"}));
