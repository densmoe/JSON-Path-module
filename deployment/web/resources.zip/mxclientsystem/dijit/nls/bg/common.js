//>>built
define("dijit/nls/bg/common",({buttonOk:"ОК",buttonCancel:"Отмени",buttonSave:"Запази",itemClose:"Затвори"}));
